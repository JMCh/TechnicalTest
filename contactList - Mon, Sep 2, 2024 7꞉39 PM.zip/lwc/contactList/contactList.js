import { LightningElement, api, wire } from 'lwc';
import getContacts from '@salesforce/apex/AccountContactController.getContacts';

export default class ContactList extends LightningElement {
    @api accountId;
    contacts;
    error;
    loading = false;

    @wire(getContacts, { accountId: '$accountId' })
    wiredContacts({ error, data }) {
        this.loading = true;
        if (data) {
            this.contacts = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.contacts = undefined;
        }
        this.loading = false;
    }
}