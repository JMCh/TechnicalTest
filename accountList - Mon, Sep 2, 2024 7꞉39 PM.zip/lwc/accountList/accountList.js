import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountContactController.getAccounts';

export default class AccountList extends LightningElement {
    accounts;
    error;
    loading = true;
    selectedAccountId;

    @wire(getAccounts)
    wiredAccounts({ error, data }) {
        if (data) {
            this.accounts = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.accounts = undefined;
        }
        this.loading = false;
    }

    handleAccountClick(event) {
        this.selectedAccountId = event.target.dataset.id;
    }
}